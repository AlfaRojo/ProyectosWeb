const admin = require('firebase-admin');

admin.initializeApp();
const db = admin.firestore();

exports.criptoCRUD = async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') {
    // Send response to OPTIONS requests
    res.set('Access-Control-Allow-Methods', 'GET');
    res.set('Access-Control-Allow-Origin', '*');
    res.set("Access-Control-Allow-Headers", "*");
    res.set("Access-Control-Allow-Credentials", "true");
    res.set("Origin", "*");
    res.set('Access-Control-Max-Age', '3600');
    res.status(204).send('');
  }
  const { userName, cryptoData, cryptoID, cryptoReq } = req.body;
  switch(cryptoReq){
    case 'CREATE':
      newCryptoID = await createCrypto(userName, cryptoData, cryptoID);
      console.log('newCrypto =>', newCryptoID)
      return res.status(200).json({ message: 'New Crypto' });
    case 'GET':
      userCryptos = await getCryptos(userName)
      console.log('All Cryptos =>', userCryptos)
      res.status(200).json({ message: 'All coins', cryptos: userCryptos });
    case 'GETid':
      userCrypto = await getCrypto(userName,cryptoID)
      console.log('Single Crypto =>', userCrypto)
      res.status(200).json({ message: 'All coins', cryptos: userCrypto });
    case 'UPDATE':
      udpatedCrypto = await updateCrypto(userName,cryptoID, cryptoData)
      console.log('Updated crypto =>', udpatedCrypto)
      res.status(200).json({ message: 'All coins', cryptos: userCrypto });
    case 'DELETE':
      deletedCrypto = await deleteCrypto(userName, cryptoID)
      console.log('Deleted Crypto =>', deletedCrypto)
      res.status(200).json({ message: 'Crypto deleted' });
    default: 
  }
}

// Function to create a new crypto for a user
async function createCrypto(userName, cryptoData, cryptoID) {
  const userRef = db.collection('users').doc(userName);
  const cryptosRef = userRef.collection('cryptos').doc(cryptoID);
  await cryptosRef.set(cryptoData);
  return cryptosRef.id;
}

// Function to get all cryptos for a user
async function getCryptos(userName) {
  const userRef = db.collection('users').doc(userName);
  const cryptosRef = userRef.collection('cryptos');
  const snapshot = await cryptosRef.get();
  const cryptos = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  return cryptos;
}

// Function to get a specific crypto for a user
async function getCrypto(userName, cryptoId) {
  const userRef = db.collection('users').doc(userName);
  const cryptosRef = userRef.collection('cryptos').doc(cryptoId);
  const doc = await cryptosRef.get();
  if (!doc.exists) {
    return null;
  }
  return { id: doc.id, ...doc.data() };
}

// Function to update a specific crypto for a user
async function updateCrypto(userName, cryptoId, cryptoData) {
  const userRef = db.collection('users').doc(userName);
  const cryptosRef = userRef.collection('cryptos').doc(cryptoId);
  await cryptosRef.update(cryptoData);
  return cryptoId;
}

// Function to delete a specific crypto for a user
async function deleteCrypto(userName, cryptoId) {
  const userRef = db.collection('users').doc(userName);
  const cryptosRef = userRef.collection('cryptos').doc(cryptoId);
  await cryptosRef.delete();
  return cryptoId;
};
