const admin = require('firebase-admin');
const bcrypt = require('bcrypt');

admin.initializeApp();
const db = admin.firestore();

// Create a user
exports.createUser = (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') {
    // Send response to OPTIONS requests
    res.set('Access-Control-Allow-Methods', 'GET');
    res.set('Access-Control-Allow-Origin', '*');
    res.set("Access-Control-Allow-Headers", "*");
    res.set("Access-Control-Allow-Credentials", "true");
    res.set("Origin", "*");
    res.set('Access-Control-Max-Age', '3600');
    res.status(204).send('');
  }

  const { email, password } = req.body;

  // Hash the password
  const hashedPassword = bcrypt.hashSync(password, 10);

  // Check if user already exists
  db.collection('users').doc(email).get()
    .then(doc => {
      if (doc.exists) {
        return res.status(400).json({ message: 'User with the same email already exists' });
      }

      // Create a new user
      const newUser = {
        email,
        password: hashedPassword
      };

      // Add the user to the "users" collection
      db.collection('users').doc(email).set(newUser)
        .then(() => {
          // Return a success response
          res.status(201).json({ message: 'User created successfully' });
        })
        .catch(err => {
          console.error(err);
          return res.status(500).json({ message: 'Internal server error' });
        });
    })
    .catch(err => {
      console.error(err);
      return res.status(500).json({ message: 'Internal server error' });
    });
};
