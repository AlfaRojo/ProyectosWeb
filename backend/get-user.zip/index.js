const admin = require('firebase-admin');
const bcrypt = require('bcrypt');

admin.initializeApp();
const db = admin.firestore();

// Get user name and decoded password
exports.getUser = (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') {
    // Send response to OPTIONS requests
    res.set('Access-Control-Allow-Methods', 'GET');
    res.set('Access-Control-Allow-Origin', '*');
    res.set("Access-Control-Allow-Headers", "*");
    res.set("Access-Control-Allow-Credentials", "true");
    res.set("Origin", "*");
    res.set('Access-Control-Max-Age', '3600');
    res.status(204).send('');
  }

  const { email, password } = req.body;

  // Retrieve the user from the "users" collection
  db.collection('users').doc(email).get()
    .then(doc => {
      if (!doc.exists) {
        console.log('User not found')
        return res.status(404).json({ message: 'User not found' });
      }

      const user = doc.data();

      // Compare the hashed password with the provided password
      bcrypt.compare(password, user.password)
        .then(result => {
          if (!result) {
            console.log('Incorrect password')
            return res.status(401).json({ message: 'Incorrect password' });
          }

          // Return the user's name and decoded password
          console.log('Correct username and password')
          res.status(200).json({ name: user.name, password: password });
        })
        .catch(err => {
          console.error(err);
          return res.status(500).json({ message: 'Internal server error' });
        });
    })
    .catch(err => {
      console.error(err);
      return res.status(500).json({ message: 'Internal server error' });
    });
};
